package com.cg.hrb.service;

import java.util.List;

import com.cg.hrb.entity.BookDetails;
import com.cg.hrb.entity.Hotel;

public interface IBookingService {
	long insertBookingDetails(BookDetails book);
	List<Hotel> getAllHotels();
}
