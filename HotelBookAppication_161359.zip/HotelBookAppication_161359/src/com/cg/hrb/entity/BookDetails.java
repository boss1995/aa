package com.cg.hrb.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="bookingdetails")
public class BookDetails {
	@Id
	@SequenceGenerator(name="Id_seq",sequenceName="seq_booking_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="Id_seq")
	@Column(name="id")
	private int id;
	@NotEmpty(message="Customer name is mandatory")
	@Pattern(regexp="[A-Z][a-z]{2,}",message="Customer name should start with capital letter and should contain minimum 3 letters")
	private String customername; 
	private int hotelid;
	@NotEmpty(message="No. of rooms is mandatory")
	@Pattern(regexp="^[1-9]*",message="The number of rooms should be greater than zero")
	private String noofrooms;
	private double amount;
	public BookDetails(){
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public int getHotelid() {
		return hotelid;
	}
	public void setHotelid(int hotelid) {
		this.hotelid = hotelid;
	}
	public String getNoofrooms() {
		return noofrooms;
	}
	public void setNoofrooms(String noofrooms) {
		this.noofrooms = noofrooms;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
}
