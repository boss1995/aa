package com.cg.hrb.dao;

import java.util.List;

import com.cg.hrb.entity.BookDetails;
import com.cg.hrb.entity.Hotel;

public interface IBookingDao {

	long insertBookingDetails(BookDetails book);
	List<Hotel> getAllHotels();
	
}
